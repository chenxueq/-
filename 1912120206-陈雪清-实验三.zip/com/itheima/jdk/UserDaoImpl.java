package com.itheima.jdk;

public class UserDaoImpl implements UserDao { 
	public void addUser() { 
		System.out.println(" �����û�") ;
	}
	public void deleteUser() { 
		System.out.println(" ɾ���û� ") ;
	}
}
